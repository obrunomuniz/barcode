const express = require("express");
const serverless = require("serverless-http");
const multer = require("multer");
const path = require("path");
const { PDFBarcodeJs } = require("pdf-barcode");


const app = express();

app.use(express.json());

 
app.get("/", (req, res) => {
  res.send("Hello, World!!!");
});

app.get("/healt", (req, res) => {
  res.send("Service healt");
});

module.exports.handler = serverless(app);
